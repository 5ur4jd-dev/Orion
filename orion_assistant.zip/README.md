# ORION — The Personal Assistant (Flutter skeleton)

This repository is a complete, buildable Flutter skeleton for ORION.
It includes placeholders and TODO markers for Porcupine, Vosk, and OpenRouter integrations.

Quick start:
1. Install Flutter SDK and Android SDK.
2. Set ANDROID_HOME and add platform-tools to PATH.
3. Open in VS Code.
4. Run:
   flutter pub get
   flutter run

To build release APK:
1. Create keystore, fill key.properties (see key.properties.example)
2. flutter build apk --release

TODO: Add Porcupine .ppn files to assets/porcupine/, Vosk models to assets/vosk/, and replace OpenRouter endpoint with your key.
