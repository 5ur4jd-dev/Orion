import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class PreferencesManager {
  final _secure = FlutterSecureStorage();
  static const _authKey = 'orion_auth_key';

  Future<void> init() async {
    // initialize if needed
  }

  Future<void> saveAuthKey(String key) async {
    // Do NOT log or print the key; store encrypted
    await _secure.write(key: _authKey, value: key);
  }

  Future<String?> getAuthKeyAsync() async {
    return await _secure.read(key: _authKey);
  }
}
