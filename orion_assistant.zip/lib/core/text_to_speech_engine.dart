import 'package:flutter_tts/flutter_tts.dart';
import 'multi_lang_detector.dart';

class TextToSpeechEngine {
  final FlutterTts _tts = FlutterTts();

  TextToSpeechEngine() {
    _tts.setStartHandler(() {});
    _tts.setCompletionHandler(() {});
  }

  Future<void> speak(String text) async {
    final lang = MultiLangDetector.detectLanguage(text);
    if (lang == 'hi') {
      await _tts.setLanguage('hi-IN');
    } else {
      await _tts.setLanguage('en-US');
    }
    await _tts.speak(text);
  }
}
