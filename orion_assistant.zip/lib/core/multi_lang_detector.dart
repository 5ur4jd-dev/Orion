class MultiLangDetector {
  static String detectLanguage(String text) {
    final devanagari = RegExp(r'[\u0900-\u097F]');
    if (devanagari.hasMatch(text)) return 'hi';
    return 'en';
  }
}
