import 'dart:async';

class WakeWordEngine {
  final _controller = StreamController<void>.broadcast();
  Stream<void> get onWake => _controller.stream;

  WakeWordEngine() {
    // TODO: integrate Porcupine via platform channel or native plugin.
    // Expected model path: assets/porcupine/<keyword>.ppn
  }

  void simulateWake() {
    _controller.add(null);
  }

  Future<void> start() async {
    // TODO: start native foreground service and wake-word listening
  }

  Future<void> stop() async {
    // TODO: stop listening
  }
}
