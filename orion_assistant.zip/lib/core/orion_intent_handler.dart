import 'package:flutter/material.dart';
import 'text_to_speech_engine.dart';

class OrionIntentHandler {
  final TextToSpeechEngine tts;
  OrionIntentHandler(this.tts);

  Future<void> handle(String utterance) async {
    final lower = utterance.toLowerCase();
    if (lower.contains('call')) {
      tts.speak('Would you like me to call that contact?');
      // TODO: invoke platform channel to place call
      return;
    }
    if (lower.contains('sms') || lower.contains('message')) {
      tts.speak('Who should I send the message to?');
      return;
    }
    tts.speak('I am asking the AI for help...');
    // TODO: call OpenRouter client
  }
}
