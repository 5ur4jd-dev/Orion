import 'dart:async';
import 'package:speech_to_text/speech_to_text.dart' as stt;

class SpeechToTextManager {
  final _stt = stt.SpeechToText();
  final _transcript = StreamController<String>.broadcast();
  Stream<String> get onTranscript => _transcript.stream;
  bool _available = false;

  SpeechToTextManager() {
    _init();
  }

  Future<void> _init() async {
    _available = await _stt.initialize(onStatus: (s) {}, onError: (e) {});
  }

  Future<void> startListening() async {
    if (!_available) await _init();
    await _stt.listen(onResult: (val) {
      _transcript.add(val.recognizedWords);
    }, localeId: 'en_US');
  }

  Future<void> stopListening() async {
    await _stt.stop();
  }

  // TODO: Add Vosk offline switch implementation here (native integration)
}
