import 'package:flutter/material.dart';
import '../core/wake_word_engine.dart';
import '../core/text_to_speech_engine.dart';
import '../core/speech_to_text_manager.dart';
import 'auth_screen.dart';
import 'overlay_widget.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final WakeWordEngine wake = WakeWordEngine();
  final TextToSpeechEngine tts = TextToSpeechEngine();
  final SpeechToTextManager stt = SpeechToTextManager();
  String transcript = '';

  @override
  void initState() {
    super.initState();
    wake.onWake.listen((_) {
      tts.speak('Yes? How can I help?');
    });
    stt.onTranscript.listen((text) {
      setState(() { transcript = text; });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ORION'),
        actions: [
          IconButton(icon: Icon(Icons.lock), onPressed: (){
            Navigator.of(context).push(MaterialPageRoute(builder: (_) => AuthScreen()));
          })
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Transcript:', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height:8),
            Expanded(child: SingleChildScrollView(child: Text(transcript))),
            SizedBox(height:16),
            Row(children: [
              ElevatedButton(child: Text('Test Wake'), onPressed: () { wake.simulateWake(); }),
              SizedBox(width:12),
              ElevatedButton(child: Text('Start PTT'), onPressed: () async { await stt.startListening(); }),
              SizedBox(width:12),
              ElevatedButton(child: Text('Stop PTT'), onPressed: () async { await stt.stopListening(); }),
              SizedBox(width:12),
              ElevatedButton(child: Text('Overlay'), onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => OverlayWidget()));
              }),
            ])
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.mic),
        onPressed: () async {
          await stt.startListening();
        },
      ),
    );
  }
}
