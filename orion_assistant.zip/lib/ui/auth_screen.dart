import 'package:flutter/material.dart';
import '../data/preferences_manager.dart';

class AuthScreen extends StatefulWidget {
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _controller = TextEditingController();
  final prefs = PreferencesManager();

  @override
  void initState() {
    super.initState();
    prefs.getAuthKeyAsync().then((v) {
      if (v != null) _controller.text = v;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Orion Auth')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Enter Orion Authentication Key (stored encrypted):'),
            TextField(controller: _controller, decoration: InputDecoration(hintText: 'Key')),
            SizedBox(height:12),
            ElevatedButton(
              onPressed: () async {
                await prefs.saveAuthKey(_controller.text.trim());
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Saved (encrypted)')));
              },
              child: Text('Save'),
            )
          ],
        ),
      ),
    );
  }
}
