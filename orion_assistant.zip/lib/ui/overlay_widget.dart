import 'package:flutter/material.dart';

class OverlayWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // simple in-app overlay simulation
      backgroundColor: Colors.black54,
      body: SafeArea(
        child: Center(
          child: Container(
            padding: EdgeInsets.all(16),
            margin: EdgeInsets.all(24),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('ORION Overlay', style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height:8),
              Text('Live transcription will appear here'),
              SizedBox(height:8),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                ElevatedButton(onPressed: (){}, child: Text('Stop')),
                SizedBox(width:8),
                ElevatedButton(onPressed: (){}, child: Text('Repeat')),
                SizedBox(width:8),
                ElevatedButton(onPressed: (){}, child: Text('More')),
              ])
            ]),
          ),
        ),
      ),
    );
  }
}
