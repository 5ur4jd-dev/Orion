class Strings {
  static const appName = 'ORION';
}
