import 'package:flutter/material.dart';
class AppColors {
  static const primary = Colors.indigo;
}
