import 'dart:convert';
import 'package:http/http.dart' as http;
import '../data/preferences_manager.dart';

class OpenRouterClient {
  final PreferencesManager prefs;
  OpenRouterClient(this.prefs);

  Future<String> ask(String prompt) async {
    final key = await prefs.getAuthKeyAsync();
    if (key == null || key.isEmpty) {
      throw Exception('Orion authentication key not set');
    }
    // TODO: Replace with real OpenRouter endpoint and request schema
    final url = Uri.parse('https://api.openrouter.example/v1/chat');
    final resp = await http.post(url, headers: {
      'Authorization': 'Bearer \$key',
      'Content-Type': 'application/json'
    }, body: jsonEncode({'prompt': prompt}));
    if (resp.statusCode == 200) {
      return resp.body;
    } else {
      throw Exception('OpenRouter call failed: \${resp.statusCode}');
    }
  }
}
