import 'package:flutter/services.dart';

class NativeServiceWrapper {
  static const MethodChannel _channel = MethodChannel('orion/native');

  static Future<void> startWakeService() async {
    await _channel.invokeMethod('startWakeService');
  }

  static Future<void> stopWakeService() async {
    await _channel.invokeMethod('stopWakeService');
  }
}
