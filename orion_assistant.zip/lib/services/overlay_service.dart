import 'package:flutter/services.dart';

class OverlayService {
  static const MethodChannel _channel = MethodChannel('orion/overlay');

  static Future<void> showOverlay() async {
    await _channel.invokeMethod('showOverlay');
  }

  static Future<void> hideOverlay() async {
    await _channel.invokeMethod('hideOverlay');
  }
}
