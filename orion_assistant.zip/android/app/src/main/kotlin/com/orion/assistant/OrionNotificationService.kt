package com.orion.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class OrionNotificationService : NotificationListenerService() {
    private val TAG = "OrionNotifService"
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        Log.d(TAG, "Notification posted: \$sbn")
    }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        Log.d(TAG, "Notification removed: \$sbn")
    }
}
