package com.orion.assistant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
    // MainActivity left minimal; native services live in separate classes
}
