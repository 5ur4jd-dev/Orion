package com.orion.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.util.Log

class OrionAccessibilityService : AccessibilityService() {
    private val TAG = "OrionAccessibility"
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        Log.d(TAG, "Accessibility event: \$event")
    }
    override fun onInterrupt() {}
}
