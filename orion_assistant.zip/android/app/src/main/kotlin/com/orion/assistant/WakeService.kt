package com.orion.assistant

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log

class WakeService : Service() {
    private val TAG = "WakeService"
    override fun onBind(intent: Intent?): IBinder? { return null }
    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "WakeService created - TODO: implement foreground notification & Porcupine integration")
    }
}
