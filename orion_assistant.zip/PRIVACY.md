Privacy Notice

- Orion may process voice audio locally or send to AI services depending on configuration.
- The Orion Authentication Key is stored encrypted.
- To remove data: uninstall the app and delete secure storage entries.
